const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    const posts = JSON.parse(fs.readFileSync('./data/posts.json', 'utf-8'));
    res.render('index', { posts });
});

app.get('/post/:id', (req, res) => {
    const posts = JSON.parse(fs.readFileSync('./data/posts.json', 'utf-8'));
    const post = posts.find(p => p.id === req.params.id);
    if (!post) return res.status(404).send('Post not found');
    res.render('post', { post });
});

app.get('/new', (req, res) => {
    res.render('new');
});

app.post('/new', (req, res) => {
    const posts = JSON.parse(fs.readFileSync('./data/posts.json', 'utf-8'));
    const { title, content } = req.body;
    const id = Date.now().toString();
    posts.push({ id, title, content });
    fs.writeFileSync('./data/posts.json', JSON.stringify(posts, null, 2));
    res.redirect('/');
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});